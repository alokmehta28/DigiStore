export default [
    {
        id:1,
        name:"E commerce App UI Kit",
        price:10,
        image:'/sample2.jpg',
        user:{
            image:'/user.png',
            name:'Kushal'
        }
    },
    {
        id:1,
        name:"E commerce App UI Kit",
        price:10,
        image:'/sample2.jpg',
        user:{
            image:'/user.png',
            name:'Kushal'
        }
    },
    {
        id:1,
        name:"E commerce App UI Kit",
        price:10,
        image:'/sample2.jpg',
        user:{
            image:'/user.png',
            name:'Kushal'
        }
    },
]