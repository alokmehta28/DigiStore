import React from "react";

function SimilarProduct({category}) {
    return (
        <div>SimilarProduct</div>
    )
}

export default SimilarProduct